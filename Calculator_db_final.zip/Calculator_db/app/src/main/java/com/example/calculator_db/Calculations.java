package com.example.calculator_db;

public class Calculations {
    int number1, number2;
    double reslt;
    String operator;

    public Calculations() {
    }

    public int getNumber1() {
        return number1;
    }

    public void setNumber1(int number1) {
        this.number1 = number1;
    }

    public int getNumber2() {
        return number2;
    }

    public void setNumber2(int number2) {
        this.number2 = number2;
    }

    public double getReslt() {
        return reslt;
    }

    public void setReslt(double reslt) {
        this.reslt = reslt;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
}
